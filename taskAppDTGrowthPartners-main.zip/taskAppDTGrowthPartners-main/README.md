<div align="center">
<img width="1200" height="475" alt="GHBanner" src="http://dtgrowthpartners.com/wp-content/uploads/2025/11/Mesa-de-trabajo-1.png">
</div>
